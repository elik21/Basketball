package com.eli.basketballgames.Models;

public class Team {
    private String Tname;
    private String TshortColor;
    private String sign;
    private int twothrows;
    private int threethrows;
    private int basketsfrom2;
    private int basketsfrom3;
}
