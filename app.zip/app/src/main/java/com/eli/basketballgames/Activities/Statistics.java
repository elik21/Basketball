package com.eli.basketballgames.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.eli.basketballgames.R;

public class Statistics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
    }
}